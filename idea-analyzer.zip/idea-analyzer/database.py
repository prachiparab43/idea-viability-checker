import sqlite3
import os
from datetime import datetime

def get_db_connection():
    """Get database connection that works on Vercel"""
    
    # On Vercel, store in /tmp directory
    if os.environ.get('VERCEL'):
        db_path = '/tmp/ideas.db'
    else:
        db_path = 'ideas.db'
    
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize database with tables"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Ideas table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS ideas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            idea TEXT NOT NULL,
            industry TEXT,
            score INTEGER,
            market_size TEXT,
            competition TEXT,
            trends TEXT,
            recommendations TEXT,
            risks TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # User feedback table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            idea_id INTEGER,
            rating INTEGER,
            comments TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (idea_id) REFERENCES ideas (id)
        )
    ''')
    
    # Industry stats table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS industry_stats (
            industry TEXT PRIMARY KEY,
            avg_score REAL,
            total_ideas INTEGER,
            last_updated TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

def save_analysis_db(idea, analysis, industry):
    """Save analysis to database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Convert lists to strings for storage
    recommendations_str = '|'.join(analysis.get('recommendations', []))
    risks_str = '|'.join(analysis.get('risks', []))
    
    cursor.execute('''
        INSERT INTO ideas (idea, industry, score, market_size, competition, trends, recommendations, risks)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        idea[:500],  # Limit length
        industry,
        analysis.get('score', 0),
        analysis.get('market_size', ''),
        analysis.get('competition', ''),
        analysis.get('trends', '')[:200],
        recommendations_str[:500],
        risks_str[:500]
    ))
    
    idea_id = cursor.lastrowid
    
    # Update industry stats
    cursor.execute('''
        INSERT OR REPLACE INTO industry_stats (industry, avg_score, total_ideas, last_updated)
        VALUES (
            ?,
            COALESCE((SELECT AVG(score) FROM ideas WHERE industry = ?), 0),
            COALESCE((SELECT COUNT(*) FROM ideas WHERE industry = ?), 0),
            CURRENT_TIMESTAMP
        )
    ''', (industry, industry, industry))
    
    conn.commit()
    conn.close()
    return idea_id

def get_recent_analyses_db(limit=10):
    """Get recent analyses from database"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT * FROM ideas 
        ORDER BY created_at DESC 
        LIMIT ?
    ''', (limit,))
    
    rows = cursor.fetchall()
    
    # Convert rows to dictionaries
    analyses = []
    for row in rows:
        analysis = dict(row)
        # Convert string lists back to lists
        analysis['recommendations'] = analysis['recommendations'].split('|') if analysis['recommendations'] else []
        analysis['risks'] = analysis['risks'].split('|') if analysis['risks'] else []
        analyses.append(analysis)
    
    conn.close()
    return analyses

def get_industry_stats_db():
    """Get industry statistics"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute('SELECT * FROM industry_stats ORDER BY total_ideas DESC')
    stats = cursor.fetchall()
    
    conn.close()
    return [dict(stat) for stat in stats]